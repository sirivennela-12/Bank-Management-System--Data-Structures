package FinalProject;

import java.util.Scanner;

public class BankManagementSystemProject
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        Bank bank = new Bank();
        FileHandler.loadAccounts(bank); 

        TransactionList  tlist = new TransactionList();
        StackTransaction stack = new StackTransaction();
        CustomerQueue    queue = new CustomerQueue();
        PriorityQueue    pq    = new PriorityQueue();

        int choice;

        do
        {
            System.out.println("\n===== BANK MANAGEMENT SYSTEM =====");
            System.out.println("1.  Add New Account");
            System.out.println("2.  Display All Accounts");
            System.out.println("3.  Search Account (Linear Search)");
            System.out.println("4.  Sort Accounts (Merge Sort)");
            System.out.println("5.  Deposit");
            System.out.println("6.  Withdraw");
            System.out.println("8.  View Transaction History");
            System.out.println("9.  Join Waiting Queue");
            System.out.println("10. Serve Next Customer");
            System.out.println("11. Display Waiting Queue");
            System.out.println("12. Build Priority Queue (Sort first)");
            System.out.println("13. Serve VIP Customer");
            System.out.println("14. Display Priority Queue");
            System.out.println("0.  Exit");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice)
            {
                case 1:
                    System.out.print("Name: ");
                    String newName = sc.nextLine();

                    if (bank.searchByName(newName) != null)
                    {
                        System.out.println("Account already exists.");
                        break;
                    }

                    System.out.print("Phone: ");
                    String newPhone = sc.nextLine();

                    System.out.print("Email: ");
                    String newEmail = sc.nextLine();

                    System.out.print("Balance: ");
                    double newBal = sc.nextDouble();
                    sc.nextLine();

                    bank.addAccount(new Account(newName, newPhone, newEmail, newBal));
                    tlist.add("New account opened for " + newName);

                    FileHandler.saveAccounts(bank);   
                    break;

                case 2:
                    bank.displayAllAccounts();
                    break;

                case 3:
                    System.out.print("Enter name: ");
                    Account found = bank.searchByName(sc.nextLine());

                    if (found != null) found.display();
                    else System.out.println("Not found.");
                    break;

                case 4:
                    bank.mergeSort();
                    bank.displayAllAccounts();

                    pq = new PriorityQueue();
                    for (int i = 0; i < bank.totalAccounts; i++)
                        pq.enqueue(i + 1, bank.accounts[i]);

                    System.out.println("Priority queue built automatically based on balance.");
                    break;

                case 5:
                    System.out.print("Name: ");
                    Account d = bank.searchByName(sc.nextLine());

                    if (d == null)
                    {
                        System.out.println("Account not found.");
                        break;
                    }

                    System.out.print("Amount: ");
                    double da = sc.nextDouble();
                    sc.nextLine();

                    d.balance += da;
                    stack.push(d, "deposit", da);
                    tlist.add("Deposit Rs." + da + " to " + d.name);

                    FileHandler.saveAccounts(bank);   
                    break;

                case 6:
                    System.out.print("Name: ");
                    Account w = bank.searchByName(sc.nextLine());

                    if (w == null)
                    {
                        System.out.println("Account not found.");
                        break;
                    }

                    System.out.print("Amount: ");
                    double wa = sc.nextDouble();
                    sc.nextLine();

                    if (wa > w.balance)
                    {
                        System.out.println("Insufficient balance");
                        break;
                    }

                    w.balance -= wa;
                    stack.push(w, "withdraw", wa);
                    tlist.add("Withdraw Rs." + wa + " from " + w.name);

                    FileHandler.saveAccounts(bank);  
                    break;

                case 8:
                    tlist.display();
                    break;

                case 9:
                    System.out.print("Customer name: ");
                    Account qAcc = bank.searchByName(sc.nextLine());

                    if (qAcc != null)
                        queue.enqueue(qAcc);
                    else
                        System.out.println("Account not found.");
                    break;

                case 10:
                    Account next = queue.dequeue();

                    if (next != null)
                    {
                        System.out.println("Now serving: " + next.name);
                        next.display();
                    }
                    else
                        System.out.println("No customers in queue.");
                    break;

                case 11:
                    queue.display();
                    break;

                case 12:
                    bank.mergeSort();

                    pq = new PriorityQueue();
                    for (int i = 0; i < bank.totalAccounts; i++)
                        pq.enqueue(i + 1, bank.accounts[i]);

                    System.out.println("Priority queue built based on balance.");
                    pq.display();
                    break;

                case 13:
                    Account vip = pq.dequeue();

                    if (vip != null)
                    {
                        System.out.println("Now serving VIP: " + vip.name);
                        vip.display();
                    }
                    else
                        System.out.println("No VIP customers.");
                    break;

                case 14:
                    pq.display();
                    break;

                case 0:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice");
            }

        } while(choice != 0);

        sc.close();
    }
}