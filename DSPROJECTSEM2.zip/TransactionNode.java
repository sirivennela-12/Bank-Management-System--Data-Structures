package FinalProject;

class TNode
{
    String data;
    TNode  next;

    TNode(String data) { this.data = data; }
}