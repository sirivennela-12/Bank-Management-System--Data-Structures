package FinalProject;

class Bank
{
    Account[] accounts;
    int totalAccounts;

    Bank()
    {
        accounts      = new Account[10];
        totalAccounts = 5;

        accounts[0] = new Account("Arun",   "9988776655", "arun@gmail.com",   3000);
        accounts[1] = new Account("Anjali",  "9123456780", "anjali@gmail.com", 12000);
        accounts[2] = new Account("Siri",    "9345678901", "siri@gmail.com",   2000);
        accounts[3] = new Account("Neha",    "9090909090", "neha@gmail.com",   8500);
        accounts[4] = new Account("Rahul",   "9876543210", "rahul@gmail.com",  5000);
    }

    void addAccount(Account acc)
    {
        if (totalAccounts == accounts.length)
        {
            Account[] bigger = new Account[accounts.length + 5];
            for (int i = 0; i < totalAccounts; i++)
                bigger[i] = accounts[i];
            accounts = bigger;
        }
        accounts[totalAccounts++] = acc;
        System.out.println("Account created successfully!");
        acc.display();
    }

    void mergeSort()
    {
        mergeSortHelper(0, totalAccounts - 1);
    }

    void mergeSortHelper(int low, int high)
    {
        if (low < high)
        {
            int mid = (low + high) / 2;
            mergeSortHelper(low, mid);
            mergeSortHelper(mid + 1, high);
            merge(low, mid, high);
        }
    }

    void merge(int low, int mid, int high)
    {
        Account[] temp = new Account[totalAccounts];
        int i = low, j = mid + 1, k = low;

        while (i <= mid && j <= high)
        {
            if (accounts[i].balance >= accounts[j].balance)
                temp[k++] = accounts[i++];
            else
                temp[k++] = accounts[j++];
        }

        while (i <= mid)  temp[k++] = accounts[i++];
        while (j <= high) temp[k++] = accounts[j++];

        for (int m = low; m <= high; m++)
            accounts[m] = temp[m];
    }

    Account searchByName(String name)
    {
        for (int i = 0; i < totalAccounts; i++)
            if (accounts[i].name.equalsIgnoreCase(name))
                return accounts[i];
        return null;
    }

    void displayAllAccounts()
    {
        System.out.println("\n===== All Accounts =====");
        for (int i = 0; i < totalAccounts; i++)
            accounts[i].display();
    }
}