package FinalProject;

class TransactionList
{
    TNode head = null;

    void add(String data)
    {
        TNode newNode = new TNode(data);

        if (head == null) { head = newNode; return; }

        TNode temp = head;
        while (temp.next != null)
            temp = temp.next;
        temp.next = newNode;
    }

    void display()
    {
        if (head == null) { System.out.println("No transactions yet."); return; }

        System.out.println("\n===== Transaction History =====");
        TNode temp  = head;
        int   count = 1;
        while (temp != null)
        {
            System.out.println(count++ + ". " + temp.data);
            temp = temp.next;
        }
    }
}