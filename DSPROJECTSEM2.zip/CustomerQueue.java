package FinalProject;

class CustomerQueue
{
    Account[] queue = new Account[10];
    int front = 0;
    int rear  = 0;
    int size  = 0;

    void enqueue(Account acc)
    {
        if (size == queue.length) { System.out.println("Queue is full."); return; }

        queue[rear++] = acc;
        size++;
        System.out.println(acc.name + " joined the waiting queue. Position: " + size);
    }

    Account dequeue()
    {
        if (size == 0) return null;

        size--;
        return queue[front++];
    }

    void display()
    {
        if (size == 0) { System.out.println("Waiting queue is empty."); return; }

        System.out.println("\n===== Customer Waiting Queue =====");
        for (int i = front; i < rear; i++)
            System.out.println("  Position " + (i - front + 1) + " : " + queue[i].name);
    }
}
