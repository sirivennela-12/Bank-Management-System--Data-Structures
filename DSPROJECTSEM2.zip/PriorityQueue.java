package FinalProject;

class PriorityQueue
{
    PQNode front = null;

    void enqueue(int priority, Account acc)
    {
        PQNode newNode = new PQNode(priority, acc);

        if (front == null || priority < front.priority)
        {
            newNode.next = front;
            front        = newNode;
        }
        else
        {
            PQNode temp = front;
            while (temp.next != null && temp.next.priority <= priority)
                temp = temp.next;
            newNode.next = temp.next;
            temp.next    = newNode;
        }

        System.out.println(acc.name + " added to priority queue with priority " + priority);
    }

    Account dequeue()
    {
        if (front == null) { System.out.println("Priority queue is empty."); return null; }

        Account acc = front.account;
        front       = front.next;
        return acc;
    }

    void display()
    {
        if (front == null) { System.out.println("Priority queue is empty."); return; }

        System.out.println("\n===== Priority Queue (VIP Customers) =====");
        PQNode temp = front;
        while (temp != null)
        {
            System.out.println("  Priority " + temp.priority + " -> " + temp.account.name);
            temp = temp.next;
        }
    }
}