package FinalProject;

import java.io.*;

public class FileHandler
{
   
    public static void saveAccounts(Bank bank)
    {
        try
        {
            File file = new File("accounts.txt");
            System.out.println("Saving to: " + file.getAbsolutePath());

            FileWriter fw = new FileWriter(file);

            for(int i = 0; i < bank.totalAccounts; i++)
            {
                Account acc = bank.accounts[i];

                fw.write(acc.name + "," +
                         acc.phone + "," +
                         acc.email + "," +
                         acc.balance + "\n");
            }

            fw.close();
            System.out.println("Accounts saved successfully!\n");
        }
        catch(Exception e)
        {
            e.printStackTrace(); 
        }
    }

    public static void loadAccounts(Bank bank)
    {
        try
        {
            File file = new File("accounts.txt");

            if(!file.exists())
            {
                System.out.println("No previous data found. Starting fresh.");
                return;
            }

            BufferedReader br = new BufferedReader(new FileReader(file));

            String line;
            bank.totalAccounts = 0;

            while((line = br.readLine()) != null)
            {
                String parts[] = line.split(",");

                if(parts.length < 4) continue; 

                bank.accounts[bank.totalAccounts++] =
                        new Account(parts[0], parts[1], parts[2],
                        Double.parseDouble(parts[3]));
            }

            br.close();
            System.out.println("Accounts loaded successfully!\n");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}