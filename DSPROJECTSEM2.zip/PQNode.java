package FinalProject;

class PQNode
{
    int     priority;
    Account account;
    PQNode  next;

    PQNode(int priority, Account account)
    {
        this.priority = priority;
        this.account  = account;
    }
}
