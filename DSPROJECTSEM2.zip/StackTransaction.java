package FinalProject;

public class StackTransaction 
{
	StackNode top = null;

    void push(Account acc, String type, double amount)
    {
        StackNode node = new StackNode(acc, type, amount);
        node.next = top;
        top       = node;
    }

    void undo(TransactionList tlist)
    {
        if (top == null) { System.out.println("Nothing to undo."); return; }

        StackNode node = top;
        top            = top.next;

        if (node.type.equals("deposit"))
            node.acc.balance -= node.amount;
        else
            node.acc.balance += node.amount;

        tlist.add("UNDO: " + node.type + " Rs." + node.amount + " for " + node.acc.name);
        System.out.println("Undo successful.");
        node.acc.display();
    }
}
