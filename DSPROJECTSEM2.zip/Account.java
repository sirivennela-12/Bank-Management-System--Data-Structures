package FinalProject;

class Account
{
    String bankCode = "8877@XYZ";
    String accountNumber;
    String name;
    String phone;
    String email;
    double balance;

    Account(String name, String phone, String email, double balance)
    {
        this.accountNumber = generateAccountNumber();
        this.name    = name;
        this.phone   = phone;
        this.email   = email;
        this.balance = balance;
    }

    private String generateAccountNumber()
    {
        int randomPart = (int)(Math.random() * 90000) + 10000;
        return bankCode + randomPart;
    }

    void display()
    {
        System.out.println("\n--- Account Details ---");
        System.out.println("Account Number : " + accountNumber);
        System.out.println("Name           : " + name);
        System.out.println("Phone          : " + phone);
        System.out.println("Email          : " + email);
        System.out.println("Balance        : Rs." + balance);
    }
}