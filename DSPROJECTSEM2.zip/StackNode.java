package FinalProject;

class StackNode
{
    Account   acc;
    String    type;
    double    amount;
    StackNode next;

    StackNode(Account acc, String type, double amount)
    {
        this.acc    = acc;
        this.type   = type;
        this.amount = amount;
    }
}
